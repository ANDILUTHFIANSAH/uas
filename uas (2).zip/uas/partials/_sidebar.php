<!-- partial:partials/_sidebar.html -->
<head>
    <!-- ... (tag-tag lainnya) ... -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@mdi/font/css/materialdesignicons.min.css">
</head>

<nav class="sidebar sidebar-offcanvas" id="sidebar">
  <ul class="nav">
    <li class="nav-item nav-profile">
      <a href="index.php" class="nav-link">
        <div class="nav-profile-image">
          <img src="assets/images/faces-clipart/pic-1.png" alt="profile">
          <span class="login-status online"></span>
          <!--change to offline or busy as needed-->
        </div>
        <div class="nav-profile-text d-flex flex-column">
          <span class="font-weight-bold mb-2"><?php echo htmlspecialchars($_SESSION["username"]); ?></span>
        </div>
        <i class="mdi mdi-bookmark-check text-success nav-profile-badge"></i>
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="index.php">
        <span class="menu-title">Menu Utama</span>
        <i class="mdi mdi-home menu-icon"></i>
      </a>
    </li>
   

    <li class="nav-item">
      <a class="nav-link" href="add_karyawan.php">
        <span class="menu-title">Tambah Nasabah</span>
        <i class="mdi mdi-account-plus menu-icon"></i>
      </a>
    </li>
    
<li class="nav-item">
    <a class="nav-link" href="hasil_tabungan.php">
        <span class="menu-title">Tabungan Nasabah</span>
        <i class="mdi mdi-book menu-icon"></i>
    </a>
</li>
<li class="nav-item">
  <a class="nav-link" href="buku_tabungan.php">
    <span class="menu-title">Data Nasabah</span>
    <i class="mdi mdi-book-plus-multiple menu-icon"></i>
  </a>
</li>
<li class="nav-item">
  <a class="nav-link" href="info_admin.php">
    <span class="menu-title">About Us</span>
    <i class="mdi mdi-account-group menu-icon "></i>
  </a>
</li>
    </li>
    <li class="nav-item sidebar-actions">
      <span class="nav-link">
        <div class="border-bottom">
          
        </div>
       
      </span>
    </li>
  </ul>
</nav>