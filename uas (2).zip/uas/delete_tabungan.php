<?php
include('server/koneksi.php');

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Lakukan operasi penghapusan data tertentu berdasarkan ID
    $query = "UPDATE karyawan SET tanggal = NULL, jenis = NULL, berat = NULL, kredit = NULL, saldo = NULL WHERE id = '$id'";
    $result = mysqli_query($koneksi, $query);

    if ($result) {
        // Jika berhasil, lakukan tindakan yang sesuai seperti redirect atau pesan sukses
        header('location: hasil_tabungan.php');
        // Atau berikan pesan sukses
        echo "Data tabungan tertentu berhasil dihapus.";
    } else {
        // Jika gagal, tampilkan pesan error
        echo "Terjadi kesalahan: " . mysqli_error($koneksi);
    }
}
?>
