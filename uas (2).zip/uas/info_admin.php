<?php
include('partials/_header.php');
include('server/koneksi.php');

// Informasi anggota kelompok 7
$anggota_kelompok = array(
    array("Ilham Hidayat", "13020210189", "A4"),
    array("Masrun Mancari", "13020210185", "A4"),
    array("Fathur Rahman", "13020210196", "A4"),
    array("Fahrudin Raziki", "13020210204", "A4"),
    array("Andi Lutfiansah", "13020210173", "A3"),
    array("Anjaz Ansari Ashar", "13020210157", "A3"),
    // Tambahkan informasi anggota lain jika diperlukan
);

// Tampilkan tabel data anggota kelompok 7
?>
<body>
    <?php include('partials/_navbar.php'); ?>
    <div class="container-fluid page-body-wrapper">
        <?php include('partials/_sidebar.php'); ?>
        <div class="main-panel">
            <div class="content-wrapper">
                <div class="row">
                    <div class="col-12 grid-margin stretch-card">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Anggota Kelompok 7 (A3-A4)</h4>
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>Nama</th>
                                                <th>Stambuk</th>
                                                <th>Kelas</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            // Menampilkan informasi anggota dalam tabel
                                            $nomor = 1;
                                            foreach ($anggota_kelompok as $anggota) {
                                                echo "<tr>";
                                                echo "<td>" . $nomor++ . "</td>";
                                                foreach ($anggota as $info) {
                                                    echo "<td>$info</td>";
                                                }
                                                echo "</tr>";
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php include('partials/_footer.php'); ?>
        </div>
    </div>
</body>
