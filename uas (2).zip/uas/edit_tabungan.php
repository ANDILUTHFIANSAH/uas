<?php
include('partials/_header.php');
?>

<body>
    <?php
    include "server/koneksi.php";
    $id = $_GET['id'];
    $tampil = mysqli_query($koneksi, "SELECT * from Karyawan where id = '" . $_GET['id'] . "'");
    $hasil = mysqli_fetch_array($tampil);

    if (isset($_POST['kirim'])) {
        $id = $_POST['id']; // Tambahkan baris ini
        $nama = $_POST['nama_nasabah'];
        $tanggal = $_POST['tanggal'];
        $jenis = $_POST['jenis'];
        $berat = $_POST['berat'];
        $kredit = $_POST['kredit'];
        $saldo = $_POST['saldo'];
        
        $update = mysqli_query($koneksi, "UPDATE karyawan SET nama = '$nama', tanggal = '$tanggal', jenis = '$jenis', berat = '$berat', kredit = '$kredit', saldo = '$saldo' WHERE id = '$id'");
        
        if ($update) {
            header("Location: hasil_tabungan.php");
        } else {
            echo "Gagal update data: " . mysqli_error($koneksi);
        }
    }
    ?>

    <div class="container-scroller">
        <!-- ... -->
        <div class="main-panel">
            <div class="content-wrapper">
                <div class="row">
                    <div class="col-12 grid-margin stretch-card">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Menu form</h4>
                                <p class="card-description"> Edit Data Tabungan </p>
                                
                                <?php
                                $sql2 = "SELECT * FROM Karyawan WHERE id='$id'";
                                $q2 = mysqli_query($koneksi, $sql2);
                                while ($r2 = mysqli_fetch_array($q2)) {
                                    $id = $r2['id'];
                                    $nama = $r2['nama'];
                                    $tanggal = $r2['tanggal'];
                                    $jenis = $r2['jenis'];
                                    $berat = $r2['berat'];
                                    $kredit = $r2['kredit'];
                                    $saldo = $r2['saldo'];
                                ?>
                                
                                <form class="forms-sample" action="" method="POST" class="form-group">
                                    <div class="form-group">
                                        <label for="">Nama Nasabah :</label>
                                        <input type="text" name="nama_nasabah" class="form-control" placeholder="Nama Nasabah" value="<?php echo $nama; ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="">Tanggal :</label>
                                        <input type="date" name="tanggal" class="form-control" value="<?php echo $tanggal; ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="">Jenis Sampah :</label>
                                        <input type="text" name="jenis" class="form-control" placeholder="Jenis" value="<?php echo $jenis; ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="">Berat :</label>
                                        <input type="text" name="berat" class="form-control" placeholder="Berat" value="<?php echo $berat; ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="">Kredit :</label>
                                        <input type="text" name="kredit" class="form-control" placeholder="Kredit" value="<?php echo $kredit; ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="">Saldo :</label>
                                        <input type="text" name="saldo" class="form-control" placeholder="Saldo" value="<?php echo $saldo; ?>">
                                    </div>
                                    
                                    <input type="hidden" name="id" value="<?php echo $id; ?>"> <!-- Input hidden untuk ID -->
                                    <input type="submit" name="kirim" value="Save" class="btn btn-gradient-primary me-2" />
                                    <a href="hasil_tabungan.php" ?><button class="btn btn-light">Cancel</button>
                                </form>
                                
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- content-wrapper ends -->
            <!-- Bagian form atau tempat menampilkan pesan kesalahan -->

            <?php
            include('partials/_footer.php')
            ?>
</body>

</html>
