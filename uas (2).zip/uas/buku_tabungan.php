<?php
include('partials/_header.php');
?>

<body>
    <?php
    include('proses.php');
    ?>
    <div class="container-scroller">
        <?php
        include('partials/_navbar.php')
        ?>
        <div class="container-fluid page-body-wrapper">
            <?php
            include('partials/_sidebar.php')
            ?>
            <div class="main-panel">
                <div class="content-wrapper">
                    <div class="row">
                        <div class="col-12 grid-margin stretch-card">
                            <div class="card">
                                <div class="card-body">
                                    <h4 class="card-title">Data Nasabah</h4>
                                    <p class="card-description">Isi Data Nasabah</p>
                                    <form class="forms-sample" action="buku_tabungan.php" method="POST" class="form-group">
                                        <div class="form-group">
                                            <label for="">Nama Bank Sampah:</label>
                                            <input type="text" name="nama_bank" class="form-control" value="BSU Sampah Merpati" disabled>
                                        </div>
                                        <div class="form-group">
                                            <label for="">Nama Nasabah:</label>
                                            <input type="text" name="nama_nasabah" class="form-control" placeholder="Nama Nasabah">
                                        </div>
                                        <div class="form-group">
                                            <input type="submit" name="cari" value="Cari" class="btn btn-gradient-primary me-2" />
                                            
                                        </div>
                                    </form>
                                    <!-- ... (kode sebelumnya) ... -->
<?php
// Proses pengecekan apakah nama nasabah ada dalam database
if (isset($_POST['cari'])) {
    $nama = $_POST['nama_nasabah'];

    include('server/koneksi.php');

    $query = "SELECT * FROM karyawan WHERE nama = '$nama'";
    $result = mysqli_query($koneksi, $query);

    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $nama = $row['nama'];

        echo "<h4>Data Nasabah</h4>";
        echo "<p>Nama Nasabah: $nama</p>";
        echo "<p>Data Diri:</p>";
        echo "<p>Nama: " . $row['nama'] . "</p>";
        echo "<p>NIP: " . $row['nip'] . "</p>";
        echo "<p>NIK: " . $row['nik'] . "</p>";
        // Tampilkan informasi lainnya dari nasabah yang ditemukan

        // Menampilkan data tabungan
        $queryTabungan = "SELECT * FROM karyawan WHERE id = " . $row['id']; // Ubah menjadi tabel tabungan yang sesuai
        $resultTabungan = mysqli_query($koneksi, $queryTabungan);

        if (mysqli_num_rows($resultTabungan) > 0) {
            echo "<h4>Data Tabungan</h4>";
?>
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Tanggal</th>
                            <th>Jenis Sampah</th>
                            <th>Berat (kg)</th>
                            <th>Kredit</th>
                            <th>Saldo</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        while ($rowTabungan = mysqli_fetch_assoc($resultTabungan)) {
                            echo "<tr>";
                            echo "<td>" . $rowTabungan['tanggal'] . "</td>";
                            echo "<td>" . $rowTabungan['jenis'] . "</td>";
                            echo "<td>" . $rowTabungan['berat'] . "</td>";
                            echo "<td>" . $rowTabungan['kredit'] . "</td>";
                            echo "<td>" . $rowTabungan['saldo'] . "</td>";
                            echo "</tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
<?php
        } else {
            echo "<p>Data tabungan tidak ditemukan.</p>";
        }
    } else {
        echo "<p>Nasabah dengan nama '$nama' tidak ditemukan.</p>";
    }
}
?>
<!-- ... (kode setelahnya) ... -->

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
                include('partials/_footer.php')
                ?>
            </div>
        </div>
    </div>
</body>

</html>
