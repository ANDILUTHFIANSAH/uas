<?php
include "server/koneksi.php";

// Handle Tabungan Nasabah
if (isset($_POST['submit_catatan'])) {
    $nama = $_POST['nama_nasabah'];
    $tanggal = $_POST['tanggal'];
    $jenis = $_POST['jenis'];
    $berat = $_POST['berat'];
    $kredit = $_POST['kredit'];
    $saldo = $_POST['saldo'];

    // Lakukan operasi untuk memasukkan data tabungan nasabah ke dalam database
    $result = mysqli_query($koneksi, "INSERT INTO karyawan(nama, tanggal, jenis, berat, kredit, saldo) 
                                      VALUES('$nama', '$tanggal', '$jenis', '$berat', '$kredit', '$saldo')");
    if ($result) {
        // Jika berhasil, lakukan tindakan yang sesuai seperti redirect atau pesan sukses
        header('location: buku_tabungan.php');
        // Atau berikan pesan sukses
        echo "Data tabungan berhasil disimpan.";
    } else {
        // Jika gagal, tampilkan pesan error
        echo "Terjadi kesalahan: " . mysqli_error($koneksi);
    }
}
?>
