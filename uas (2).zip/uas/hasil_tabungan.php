<?php
include('partials/_header.php');
include('server/koneksi.php');

// Pagination
$batas = 10;
$halaman = isset($_GET['halaman']) ? (int)$_GET['halaman'] : 1;
$halaman_awal = ($halaman > 1) ? ($halaman * $batas) - $batas : 0;
$previous = $halaman - 1;
$next = $halaman + 1;

$query = "SELECT * FROM karyawan LIMIT $halaman_awal, $batas";
$result = mysqli_query($koneksi, $query);
$nomor = $halaman_awal + 1;

// Tampilkan tabel data tabungan
?>
<body>
    <?php include('partials/_navbar.php'); ?>
    <div class="container-fluid page-body-wrapper">
        <?php include('partials/_sidebar.php'); ?>
        <div class="main-panel">
            <div class="content-wrapper">
                <div class="row">
                    <div class="col-12 grid-margin stretch-card">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Hasil Tabungan</h4>
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>Nama Nasabah</th>
                                                <th>Tanggal</th>
                                                <th>Jenis Sampah</th>
                                                <th>Berat (kg)</th>
                                                <th>Kredit</th>
                                                <th>Saldo</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php while ($row = mysqli_fetch_array($result)) : ?>
                                                <tr>
                                                    <td><?php echo $nomor++; ?></td>
                                                    <td><?php echo $row['nama']; ?></td>
                                                    <td><?php echo $row['tanggal']; ?></td>
                                                    <td><?php echo $row['jenis']; ?></td>
                                                    <td><?php echo $row['berat']; ?></td>
                                                    <td><?php echo $row['kredit']; ?></td>
                                                    <td><?php echo $row['saldo']; ?></td>
                                                    <td>
                                                        <a href="edit_tabungan.php?id=<?php echo $row['id']; ?>"><i class="mdi mdi-pencil"></i></a>
                                                        <a href="delete_tabungan.php?id=<?php echo $row['id']; ?>"><i class="mdi mdi-delete"></i></a>
                                                    </td>
                                                </tr>
                                            <?php endwhile; ?>
                                        </tbody>
                                    </table>
                                    <!-- Pagination Links -->
                                    <nav>
                                        <ul class="pagination justify-content-center">
                                            <li class="page-item">
                                                <a class="page-link" <?php if ($halaman > 1) {
                                                    echo "href='hasil_tabungan.php?halaman=$previous'";
                                                } ?>>Previous</a>
                                            </li>
                                            <?php
                                            $query_jumlah = "SELECT COUNT(*) AS jumlah FROM karyawan";
                                            $result_jumlah = mysqli_query($koneksi, $query_jumlah);
                                            $data_jumlah = mysqli_fetch_assoc($result_jumlah);
                                            $jumlah_halaman = ceil($data_jumlah['jumlah'] / $batas);

                                            for ($i = 1; $i <= $jumlah_halaman; $i++) :
                                            ?>
                                                <li class="page-item"><a class="page-link" href="hasil_tabungan.php?halaman=<?php echo $i; ?>"><?php echo $i; ?></a></li>
                                            <?php endfor; ?>
                                            <li class="page-item">
                                                <a class="page-link" <?php if ($halaman < $jumlah_halaman) {
                                                    echo "href='hasil_tabungan.php?halaman=$next'";
                                                } ?>>Next</a>
                                            </li>
                                        </ul>
                                    </nav>
                                    <!-- End of Pagination Links -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php include('partials/_footer.php'); ?>
        </div>
    </div>
</body>
